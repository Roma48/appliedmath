$(document).ready(function() {
    $(".sub-menu").accordion({
        accordion:true,
        speed: 500,
        //closedSign: '[+]',
        //openedSign: '[-]'
    });
});